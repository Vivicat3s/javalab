package com.jit.thirdsem;

public class simple_java {
	public static void main(String[] args) {
		int a=13, b=12, c=10;
		if(a>b && a>c) {
			System.out.println("greatest="+a);
			
		}
		else if(b>a && b>c) {
			System.out.println("greatest="+b);
			
		}
		else {
			System.out.println("greatest="+c);
		}
	}

}
