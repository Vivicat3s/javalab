package com.jit.thirdsem;

public class a14 {

	public static void main(String[] args) {
		System.out.println("main bieging");
        if(true) {
        	System.out.println(1);
        }
        if(false)
			System.out.println(2);
		else {
        	System.out.println(3);
        }
        System.out.println(4);
	}

}
