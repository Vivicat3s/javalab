import java.MyClass;

public class MainClass {
    public static void main(String[] args) {
        MyClass myObject = new MyClass();
        myObject.display();
    }
}
